#import <Flutter/Flutter.h>

@interface WifiPlugin : NSObject<FlutterPlugin>
@end
