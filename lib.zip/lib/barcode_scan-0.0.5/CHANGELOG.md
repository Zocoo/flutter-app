## [0.0.4] - 2/8/17

* Fix missing gradle dependency (thanks to [toteto](https://github.com/apptreesoftware/flutter_barcode_reader/pull/15))
* Update gradle dependencies

## [0.0.3] - 2/8/17

* Improved permission handling (thanks to [BenSower](https://github.com/BenSower))
* Added MIT license

## [0.0.2] - 11/7/17

* Rewrite iOS scanner in Objective-C to avoid Swift use_frameworks! conflicts with other plugins (see https://github.com/flutter/flutter/issues/10968)

## [0.0.1] - 10/29/17

* Supports 2D & QR Codes
* Control flash while scanning
