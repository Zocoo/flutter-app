# barcode_scan_example

Demonstrates how to use the barcode_scan plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
