import 'package:flutter/material.dart';
import 'package:flutter_wyz/page/component/msg/msg_list.dart';
import 'package:flutter_wyz/page/component/msg/msg_my.dart';
import 'package:flutter_wyz/page/component/msg/msg_my_care.dart';

class MsgHome extends StatefulWidget {
  @override
  _MsgHomeState createState() => _MsgHomeState();
}

class _MsgHomeState extends State<MsgHome> {
  final List<int> _m = [0, 1, 2];
  final List<String> _ms = ['关注', '所有', '我的'];
  int _c = 1;

  getContent(int c) {
    if (c == 0) {
      return MsgMyCare();
    } else if (c == 1) {
      return MsgList();
    } else if (c == 2) {
      return MsgMy();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          color: Color.fromARGB(255, 250, 250, 250),
          height: 70,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              MaterialButton(
                onPressed: () {
                  setState(() {
                    _c = 0;
                  });
                },
                color: 0 == _c ? Colors.blueAccent : Colors.black26,
                child: Text(
                  _ms[0],
                  style: TextStyle(color: Colors.white),
                ),
              ),
              MaterialButton(
                onPressed: () {
                  setState(() {
                    _c = 1;
                  });
                },
                color: 1 == _c ? Colors.blueAccent : Colors.black26,
                child: Text(
                  _ms[1],
                  style: TextStyle(color: Colors.white),
                ),
              ),
              MaterialButton(
                onPressed: () {
                  setState(() {
                    _c = 2;
                  });
                },
                color: 2 == _c ? Colors.blueAccent : Colors.black26,
                child: Text(
                  _ms[2],
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 1,
          width: double.infinity,
          color: Color.fromARGB(255, 180, 180, 180),
        ),
        Expanded(
          child: Container(
            color: Color.fromARGB(255, 250, 250, 250),
            width: double.infinity,
            child: getContent(_c),
          ),
        )
      ],
    );
  }
}
