import 'package:flutter/material.dart';

import 'package:flutter_wyz/page/component/friend/friend_my.dart';
import 'package:flutter_wyz/page/component/friend/my_friend.dart';

class FriendAll extends StatefulWidget {
  FriendAll({Key key, this.id}) : super(key: key);

  final String id;

  @override
  _FriendAll createState() => _FriendAll(id);
}

class _FriendAll extends State<FriendAll> {
  final List<int> _m = [0, 1];
  final List<String> _ms = ['他关注的', '关注他的'];
  int _c = 0;
  String _id = "";

  _FriendAll(id) {
//    setState(() {
    _id = id;
//    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('他的好友'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            color: Color.fromARGB(255, 250, 250, 250),
            height: 70,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                MaterialButton(
                  onPressed: () {
                    setState(() {
                      _c = 0;
                    });
                  },
                  color: 0 == _c ? Colors.blueAccent : Colors.black26,
                  child: Text(
                    _ms[0],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                MaterialButton(
                  onPressed: () {
                    setState(() {
                      _c = 1;
                    });
                  },
                  color: 1 == _c ? Colors.blueAccent : Colors.black26,
                  child: Text(
                    _ms[1],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 1,
            width: double.infinity,
            color: Color.fromARGB(255, 180, 180, 180),
          ),
          Expanded(
            child: Container(
              color: Color.fromARGB(255, 250, 250, 250),
              width: double.infinity,
              child: _c == 0 ? MyFriend(id: _id) : FriendMy(id: _id),
            ),
          )
        ],
      ),
    );
  }
}
