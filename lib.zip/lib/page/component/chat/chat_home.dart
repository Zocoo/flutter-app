import 'package:flutter/material.dart';
import 'package:flutter_wyz/page/pojo/chat.dart';
import 'package:flutter_wyz/util/Toast.dart';
import 'package:flutter_wyz/util/local_storage.dart';

class ChatHome extends StatefulWidget {
  ChatHome({Key key, this.id, this.name}) : super(key: key);

  final String id;
  final String name;

  @override
  _ChatHomeState createState() => _ChatHomeState(id, name);
}

class _ChatHomeState extends State<ChatHome> {
  _ChatHomeState(id, name) {
    _id = id;
    _name = name;
    _initTestData();
  }

  String _id = "";
  TextEditingController _msgController = new TextEditingController();
  String _name = "";
  List<Chat> _list = [];
  var _controller = new ScrollController();

  _initTestData() async {
    String userId = await LocalStorage().get("userId");
    List<Chat> list = [];
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 1;
      c.content =
          "我爱上省省沙发上省发顺丰发是否安抚省反倒是发送发啊发送发是否省发送发是否省发送发沙发上发送发送发是否省发送发送发是否是否是否安抚省。";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 1;
      c.content =
          "我爱上省省沙发上省发顺丰发是否安抚省反倒是发送发啊发送发是否省发送发是否省发送发沙发上发送发送发是否省发送发送发是否是否是否安抚省。";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 1;
      c.content = "我";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 2;
      c.content =
          "http://xhpicture.oss-cn-beijing.aliyuncs.com/file/1904281842249157.png";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 2;
      c.content =
          "http://xhpicture.oss-cn-beijing.aliyuncs.com/file/1904281842249157.png";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 1;
      c.content = "我爱上省省";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 1;
      c.content =
          "我爱上省省沙发上省发顺丰发是否安抚省反倒是发送发啊发送发是否省发送发是否省发送发沙发上发送发送发是否省发送发送发是否是否是否安抚省。";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 1;
      c.content =
          "我爱上省省沙发上省发顺丰发是否安抚省反倒是发送发啊发送发是否省发送发是否省发送发沙发上发送发送发是否省发送发送发是否是否是否安抚省。";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 1;
      c.content = "我";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 2;
      c.content =
          "http://xhpicture.oss-cn-beijing.aliyuncs.com/file/1904281842249157.png";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 2;
      c.content =
          "http://xhpicture.oss-cn-beijing.aliyuncs.com/file/1904281842249157.png";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 1;
      c.content = "我爱上省省";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 1;
      c.content =
          "我爱上省省沙发上省发顺丰发是否安抚省反倒是发送发啊发送发是否省发送发是否省发送发沙发上发送发送发是否省发送发送发是否是否是否安抚省。";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 1;
      c.content =
          "我爱上省省沙发上省发顺丰发是否安抚省反倒是发送发啊发送发是否省发送发是否省发送发沙发上发送发送发是否省发送发送发是否是否是否安抚省。";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 1;
      c.content = "我";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 2;
      c.content =
          "http://xhpicture.oss-cn-beijing.aliyuncs.com/file/1904281842249157.png";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = _id;
      c.friendId = userId;
      c.type = 2;
      c.content =
          "http://xhpicture.oss-cn-beijing.aliyuncs.com/file/1904281842249157.png";
      list.add(c);
    }
    {
      Chat c = new Chat();
      c.userId = userId;
      c.friendId = _id;
      c.type = 1;
      c.content = "我爱上省省";
      list.add(c);
    }
    setState(() {
      _list = list;
    });
  }

  Widget _input() {
    return Container(
      height: 60,
      width: double.infinity,
      color: Colors.white,
      child: Row(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(right: 1),
            child: MaterialButton(
//              color: Colors.red,
              minWidth: 10,
              onPressed: () {},
              child: Icon(Icons.image),
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.only(
                right: 15,
              ),
              child: TextField(
                onTap: () {
                  new Future.delayed(
                      const Duration(milliseconds: 500),
                      () => {
                            _controller.animateTo(
                              _controller.position.maxScrollExtent,
                              duration:
                                  new Duration(milliseconds: 800), // 300ms
                              curve: Curves.bounceIn,
                            )
                          });
                },
                decoration: InputDecoration(
                  hintText: '输入',
                  suffixIcon: new IconButton(
                    icon: new Icon(Icons.send, color: Colors.blue),
                    onPressed: () {
                      if (_msgController.text == null ||
                          _msgController.text == '') {
                        Toast.toast(context, '不能发送空消息！');
                      } else {}
                    },
                  ),
                ),
                controller: _msgController,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chatList(index) {
    if (_list[index].userId == _id) {
      // 收到的消息
      if (_list[index].type == 1) {
        // 收到的文字消息
        return Container(
          padding: EdgeInsets.all(10),
//          color: Colors.red,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 40,
                width: 40,
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(6.0),
                  child: Image.network(
                      'https://assets-store-cdn.48lu.cn/assets-store/5002cfc3bf41f67f51b1d979ca2bd637.png' +
                          "?x-oss-process=image/resize,m_lfit,h_100,w_100"),
                ),
              ),
              Flexible(
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  child: Container(
                    padding:
                        EdgeInsets.only(left: 10, top: 5, bottom: 5, right: 10),
                    decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.all(Radius.circular(6))),
                    child: Text(_list[index].content,style: TextStyle(color: Color.fromARGB(255, 240, 240, 240),),),
                  ),
                ),
              ),
            ],
          ),
        );
      } else {
        // 收到的图片消息
        return Container(
          padding: EdgeInsets.all(10),
//          color: Colors.red,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 40,
                width: 40,
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(6.0),
                  child: Image.network(
                      'https://assets-store-cdn.48lu.cn/assets-store/5002cfc3bf41f67f51b1d979ca2bd637.png' +
                          "?x-oss-process=image/resize,m_lfit,h_100,w_100"),
                ),
              ),
              Flexible(
                child: Container(
                  padding: EdgeInsets.only(left: 10),
                  width: 200,
                  child: new ClipRRect(
                    borderRadius: BorderRadius.circular(6.0),
                    child: Image.network(_list[index].content),
                  ),
                ),
              ),
            ],
          ),
        );
      }
    } else {
      // 发送的消息
      if (_list[index].type == 1) {
        // 发送的文字消息
        return Container(
          padding: EdgeInsets.all(10),
//          color: Colors.red,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Flexible(
                child: Container(
                  padding: EdgeInsets.only(right: 10),
                  child: Container(
                    padding:
                        EdgeInsets.only(left: 10, top: 5, bottom: 5, right: 10),
                    decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.all(Radius.circular(6))),
                    child: Text(_list[index].content,style: TextStyle(color: Color.fromARGB(255, 240, 240, 240),),),
                  ),
                ),
              ),
              Container(
                height: 40,
                width: 40,
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(6.0),
                  child: Image.network(
                      'https://assets-store-cdn.48lu.cn/assets-store/5002cfc3bf41f67f51b1d979ca2bd637.png' +
                          "?x-oss-process=image/resize,m_lfit,h_100,w_100"),
                ),
              ),
            ],
          ),
        );
      } else {
        return Container(
          padding: EdgeInsets.all(10),
//          color: Colors.red,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              Flexible(
                child: Container(
                  padding: EdgeInsets.only(right: 10),
                  width: 200,
                  child: new ClipRRect(
                    borderRadius: BorderRadius.circular(6.0),
                    child: Image.network(_list[index].content),
                  ),
                ),
              ),
              Container(
                height: 40,
                width: 40,
                child: new ClipRRect(
                  borderRadius: BorderRadius.circular(6.0),
                  child: Image.network(
                      'https://assets-store-cdn.48lu.cn/assets-store/5002cfc3bf41f67f51b1d979ca2bd637.png' +
                          "?x-oss-process=image/resize,m_lfit,h_100,w_100"),
                ),
              ),
            ],
          ),
        );
      }
    }
  }

  Widget _msg() {
    return _list.length < 1
        ? Expanded(
            child: Container(
              child: Center(
                child: Text('暂无消息'),
              ),
            ),
          )
        : Expanded(
            child: Container(
              child: ListView.builder(
                itemCount: _list.length,
                itemBuilder: (context, index) {
                  return _chatList(index);
                },
                controller: _controller,
              ),
            ),
          );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_name),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            _msg(),
            _input(),
          ],
        ),
      ),
    );
  }
}
