import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_wyz/page/content/airplay_screen.dart';
import 'package:flutter_wyz/page/content/email_screen.dart';
import 'package:flutter_wyz/page/content/home_screen.dart';
import 'package:flutter_wyz/page/content/pages_screen.dart';
import 'package:flutter_wyz/util/local_storage.dart';

class Index extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => IndexState();
}

class IndexState extends State<Index> {
  final _bottomNavigationColor = Colors.blue;
  int _currentIndex = 0;
  List<Widget> list = List();

  IndexState() {
    initLabel();
    _tgo();
  }

  Icon _msg = Icon(
    Icons.chat,
    color: Colors.blue,
  );

  Timer _ct;

  int _i = 0;

  void _tgo() {
    _ct = Timer.periodic(new Duration(seconds: 60), (timer) {
      _i++;
      if (_i > 20) {
        setState(() {
          _msg = Icon(
            Icons.speaker_notes,
            color: Colors.redAccent,
          );
        });
      }
      print(_i);
    });
  }

  initLabel() async {
    String l = await LocalStorage().get("labelId");
    if (l != null && l.length == 1 && l != '0') {
      setState(() {
        _currentIndex = int.parse(l);
      });
      await LocalStorage().set("labelId", '0');
    }
  }

  @override
  void initState() {
    list
      ..add(HomeScreen())
      ..add(EmailScreen())
      ..add(PagesScreen())
      ..add(AirPlayScreen());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: list[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
              icon: Icon(
                Icons.home,
                color: _bottomNavigationColor,
              ),
              title: Text(
                '主页',
                style: TextStyle(color: _bottomNavigationColor),
              )),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.people,
                color: _bottomNavigationColor,
              ),
              title: Text(
                '好友',
                style: TextStyle(color: _bottomNavigationColor),
              )),
          BottomNavigationBarItem(
            icon: _msg,
            title: Text(
              '消息',
              style: TextStyle(color: _bottomNavigationColor),
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person,
              color: _bottomNavigationColor,
            ),
            title: Text(
              '我的',
              style: TextStyle(color: _bottomNavigationColor),
            ),
          ),
        ],
        currentIndex: _currentIndex,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        type: BottomNavigationBarType.shifting,
      ),
    );
  }
}
