import 'package:flutter/material.dart';
import 'package:flutter_wyz/page/component/friend/friend_my.dart';
import 'package:flutter_wyz/page/component/friend/my_friend.dart';

class EmailScreen extends StatefulWidget {
  @override
  _EmailScreen createState() => _EmailScreen();
}

class _EmailScreen extends State<EmailScreen> {
  final List<int> _m = [0, 1];
  final List<String> _ms = ['我关注的', '关注我的'];
  int _c = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('好友'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            color: Color.fromARGB(255, 250, 250, 250),
            height: 70,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                MaterialButton(
                  onPressed: () {
                    setState(() {
                      _c = 0;
                    });
                  },
                  color: 0 == _c ? Colors.blueAccent : Colors.black26,
                  child: Text(
                    _ms[0],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                MaterialButton(
                  onPressed: () {
                    setState(() {
                      _c = 1;
                    });
                  },
                  color: 1 == _c ? Colors.blueAccent : Colors.black26,
                  child: Text(
                    _ms[1],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 1,
            width: double.infinity,
            color: Color.fromARGB(255, 180, 180, 180),
          ),
          Expanded(
            child: Container(
              color: Color.fromARGB(255, 250, 250, 250),
              width: double.infinity,
              child: _c == 0 ? MyFriend(id: "0") : FriendMy(id: "0"),
            ),
          )
        ],
      ),
    );
  }
}
