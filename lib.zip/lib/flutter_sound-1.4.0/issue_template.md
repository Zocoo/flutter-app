### Version of flutter_sound

## flutter doctor

### Platforms you faced the error (IOS or Android or both?)

### Expected behavior

### Actual behavior

### Tested environment (Emulator? Real Device?)

### Steps to reproduce the behavior
