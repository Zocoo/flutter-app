class Config {
  String serverUrl = "https://co.xhznkz.com/api";
  String host = "http://ddz.so-what.cc";
}
