# Current ToDos and Future Milestones

+ Support Android down to sdk version 16
+ Support (custom) sound for notification
+ Support vibration
+ Support custom vibration pattern (maybe Android only)
+ Support MediaStyle / InboxStyle / MessagingStyle / ... (Some might be Android only)
+ 