#import <Flutter/Flutter.h>

@interface LocalNotificationsPlugin : NSObject<FlutterPlugin>
@end
