#import <Flutter/Flutter.h>

@interface SimplePermissionsPlugin : NSObject<FlutterPlugin>
@end
