#import <Flutter/Flutter.h>

@interface FlutterImageCompressPlugin : NSObject<FlutterPlugin>

+(BOOL) showLog;

@end
