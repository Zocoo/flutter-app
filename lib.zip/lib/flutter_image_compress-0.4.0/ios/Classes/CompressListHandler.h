//
//  CompressListHandler.h
//  flutter_image_compress
//
//  Created by cjl on 2018/9/8.
//

#import <Foundation/Foundation.h>

@interface CompressListHandler : NSObject

- (void)handleMethodCall:(FlutterMethodCall *)call result:(FlutterResult)result;
@end
