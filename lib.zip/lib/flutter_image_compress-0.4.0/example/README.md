# flutter_image_compress_example

Demonstrates how to use the flutter_image_compress plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
