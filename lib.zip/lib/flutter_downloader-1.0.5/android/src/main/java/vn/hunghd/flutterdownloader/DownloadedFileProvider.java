package vn.hunghd.flutterdownloader;

import android.support.v4.content.FileProvider;

public class DownloadedFileProvider extends FileProvider {
}
