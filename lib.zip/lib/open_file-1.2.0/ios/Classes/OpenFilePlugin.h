#import <Flutter/Flutter.h>

@interface OpenFilePlugin : NSObject<FlutterPlugin>
@end
@interface UIDocumentInteractionControllerDelegate
@end
