#import <Flutter/Flutter.h>

@interface ImageCropPlugin : NSObject<FlutterPlugin>
@end
